<?php
   
	$caption = str_replace(array('\\n','\\')," ",'ab\n \as');
		echo $caption;